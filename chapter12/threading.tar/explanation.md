Threading Project explanation:

Thread control block design

- Thread control blocks are designed as structs, encompassing all the fields that would be necessary for a thread.
- We have sp, the stack pointer of the current thread, that is used by ctx_switch and ctx_start. This houses all the relevant registers for this thread, so switching/startign is simply a matter of reading off the new registers from the stack.
- We have stack_base, which also points to the stack, but sp points to where the program is currently executing while the stack_base points to the original pointer location on the stack. This is necessary when it comes time to free a thread.
- We have stack_size, which is just atop stack_base and is how much space each thread is allowed to use in its stack.
- We have state, which is the current state of the thread -- a runnable (either currently executing or in a runnable queue), sleeping (waiting for some future deadline), waiting input (waiting for some keystroke), and waiting for a semaphore.
- We have wake_time, which for sleeping threads represents what time the thread should wake up at, in ns from boot time
- We have input_result, which is a private keyboard entry for each thread, to avoid one keystroke activating all threads.
- We have waiting_on, which is a pointer to the semaphore that the current thread is waiting for.
- We have next, which is a next pointer, for whichever one of the queues (see below) that the current thread is on.
- We have func and arg, which is the actual logic that this thread wants to do.
- Finally, started tracks whether this thread needs to be started or switched into.

Run-queue organization

- Instead of just a run queue and zombie queue from the slides, we have 4 queues. run_queue for runnables (ready to go), sleep_queue for waiting for a deadline, input_queue for waiting for a keystroke, and zombie_queue for threads that need to be freed. This is beneficial because it allows for separation of different thread reasons, and avoids having to check at each thread in a master run_queue is waiting for a deadline or a keystroke or something else. The run_queue has a head and tail pointer, and uses that structure to help with appending and checking for NULL cases. 


Input multiplexing approach
- input_queue manages multiplexing, with the schedule function orchestrating keystrokes for the current thread and blocking if waiting. That way, a thread isn't just spinning till it receives input but gives up control to a thread that is able to run while it is waiting for a keystroke.


Semaphore blocking and wake-up logic
- Semaphores are defined as a struct with a count of the number of threads that can access it now, and a waiters list. Thus, each semaphore has its own queue of threads, and sema_inc unblocks one thread and increases the count accordingly, while sema_dec does the opposite. Thus, the application code can use these two as lock and unlocks and readily access the waiters. 


AI Statement:

Used Claude Sonnet to develop pseudocode roadmap for how to implement functions. Used Claude Code to better understand what functions do, for some of the in line comments, and for code logic help, especially with schedule.


Instructions on how to play the game:
Catch balls falling from the top of the screen with your basket (represented as a bar) before they reach the bottom of the screen.
Press 'a' on the keyboard to move your basket left and 'd' to move your basket right. If the ball lands into the basket, you get a
point, otherwise the computer gets a point. Press 'q' to exit the game.